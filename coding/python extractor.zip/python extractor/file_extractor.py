import os
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading

class FileExtractorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("File Extractor")
        self.root.geometry("600x400")
        self.root.resizable(True, True)
        
        self.setup_ui()
    
    def setup_ui(self):
        source_frame = tk.Frame(self.root, pady=10)
        source_frame.pack(fill=tk.X, padx=20)
        
        tk.Label(source_frame, text="Source:").pack(side=tk.LEFT, padx=(0, 10))
        
        self.source_path_var = tk.StringVar()
        tk.Entry(source_frame, textvariable=self.source_path_var, width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        tk.Button(source_frame, text="Browse File", command=self.browse_source_file).pack(side=tk.RIGHT, padx=(5, 0))
        tk.Button(source_frame, text="Browse Folder", command=self.browse_source_folder).pack(side=tk.RIGHT, padx=(5, 0))
        
        dest_frame = tk.Frame(self.root, pady=10)
        dest_frame.pack(fill=tk.X, padx=20)
        
        tk.Label(dest_frame, text="Destination:").pack(side=tk.LEFT, padx=(0, 10))
        
        self.dest_path_var = tk.StringVar()
        tk.Entry(dest_frame, textvariable=self.dest_path_var, width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        tk.Button(dest_frame, text="Browse", command=self.browse_destination).pack(side=tk.RIGHT, padx=(10, 0))
        
        options_frame = tk.Frame(self.root, pady=10)
        options_frame.pack(fill=tk.X, padx=20)
        
        self.copy_var = tk.BooleanVar(value=True)
        tk.Radiobutton(options_frame, text="Copy files", variable=self.copy_var, value=True).pack(side=tk.LEFT, padx=(0, 10))
        tk.Radiobutton(options_frame, text="Move files", variable=self.copy_var, value=False).pack(side=tk.LEFT)
        
        progress_frame = tk.Frame(self.root, pady=10)
        progress_frame.pack(fill=tk.X, padx=20)
        
        self.progress = ttk.Progressbar(progress_frame, orient=tk.HORIZONTAL, length=100, mode='determinate')
        self.progress.pack(fill=tk.X)
        
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        status_label = tk.Label(self.root, textvariable=self.status_var, bd=1, relief=tk.SUNKEN, anchor=tk.W)
        status_label.pack(side=tk.BOTTOM, fill=tk.X)
        
        list_frame = tk.Frame(self.root)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        tk.Label(list_frame, text="Files to extract:").pack(anchor=tk.W)
        
        self.files_listbox = tk.Listbox(list_frame)
        self.files_listbox.pack(fill=tk.BOTH, expand=True)
        
        button_frame = tk.Frame(self.root, pady=10)
        button_frame.pack()
        
        self.extract_button = tk.Button(button_frame, text="Extract Files", command=self.start_extraction, width=15, height=2)
        self.extract_button.pack()
    
    def browse_source_file(self):
        filetypes = [("All files", "*.*")]
        filename = filedialog.askopenfilename(title="Select file to extract", filetypes=filetypes)
        if filename:
            self.source_path_var.set(filename)
            self.update_files_list()
    
    def browse_source_folder(self):
        directory = filedialog.askdirectory(title="Select folder to extract")
        if directory:
            self.source_path_var.set(directory)
            self.update_files_list()
    
    def browse_destination(self):
        directory = filedialog.askdirectory(title="Select extraction destination")
        if directory:
            self.dest_path_var.set(directory)
    
    def update_files_list(self):
        self.files_listbox.delete(0, tk.END)
        source_path = self.source_path_var.get()
        
        if not source_path or not os.path.exists(source_path):
            return
        
        if os.path.isfile(source_path):
            self.files_listbox.insert(tk.END, os.path.basename(source_path))
        else:
            for root, _, files in os.walk(source_path):
                for file in files:
                    rel_path = os.path.relpath(os.path.join(root, file), source_path)
                    self.files_listbox.insert(tk.END, rel_path)
    
    def start_extraction(self):
        source_path = self.source_path_var.get()
        dest_path = self.dest_path_var.get()
        
        if not source_path or not os.path.exists(source_path):
            messagebox.showerror("Error", "Please select a valid source file or folder.")
            return
        
        if not dest_path:
            messagebox.showerror("Error", "Please select a destination folder.")
            return
        
        self.extract_button.config(state=tk.DISABLED)
        self.progress['value'] = 0
        self.status_var.set("Extracting files...")
        
        threading.Thread(target=self.extract_files, args=(source_path, dest_path)).start()
    
    def extract_files(self, source_path, dest_path):
        try:
            if not os.path.exists(dest_path):
                os.makedirs(dest_path)
            
            total_files = 0
            files_to_process = []
            
            if os.path.isfile(source_path):
                total_files = 1
                files_to_process.append((source_path, os.path.join(dest_path, os.path.basename(source_path))))
            else:
                for root, _, files in os.walk(source_path):
                    for file in files:
                        total_files += 1
                        src_file = os.path.join(root, file)
                        rel_path = os.path.relpath(src_file, source_path)
                        dst_file = os.path.join(dest_path, rel_path)
                        files_to_process.append((src_file, dst_file))
            
            for i, (src_file, dst_file) in enumerate(files_to_process):
                os.makedirs(os.path.dirname(dst_file), exist_ok=True)
                
                if self.copy_var.get():
                    shutil.copy2(src_file, dst_file)
                    operation = "copied"
                else:
                    shutil.move(src_file, dst_file)
                    operation = "moved"
                
                progress_value = int((i + 1) / total_files * 100)
                self.root.after(0, lambda v=progress_value: self.progress.config(value=v))
                self.root.after(0, lambda f=os.path.basename(src_file), op=operation: 
                               self.status_var.set(f"File {f} {op}... ({i+1}/{total_files})"))
            
            self.root.after(0, lambda: messagebox.showinfo("Success", f"All files have been successfully extracted to {dest_path}"))
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Error", f"Extraction failed: {str(e)}"))
        finally:
            self.root.after(0, self.reset_ui)
    
    def reset_ui(self):
        self.extract_button.config(state=tk.NORMAL)
        self.status_var.set("Ready")

def main():
    root = tk.Tk()
    app = FileExtractorApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
